token = "1047594455:AAGGblu9FGRNgPkjMEcbX7I5BuwDHUBQqsI"
MODULE_NAME = "admin"

MESSAGE_AMOUNT = "People registered: "
MESSAGE_UNAUTHORIZED = "Unauthorized access attempt. Administrator was notified"
MESSAGE_SENT_EVERYBODY = "Message has been sent to everybody"
MESSAGE_SENT_PERSONAL = "Message has been sent"
MESSAGE_ABORTED = "Aborted"
MESSAGE_USER_NOT_FOUND = "User not found"
MESSAGE_EXCEPTION = "Exception occurred:\n"
MESSAGE_SCHEDULE_UPDATED = "Schedule is updated"


REQUEST_SPAM_MESSAGE = "With great power comes great responsibility!\nWhat do you want to spam everyone?"
REQUEST_PERSONAL_ALIAS = "Write telegram alias for personal message"
REQUEST_PERSONAL_MESSAGE = "Write your personal message to "

ADMIN_LIST = []
SUPERADMIN_LIST = []
