MODULE_NAME = "sample"
TEXT_DEFAULT_STRING = "Information wants to be free"
MESSAGE_STRING_SAVED = "New string is saved successfully"
REQUEST_FAVORITE_STRING = "What is your favorite string?"
